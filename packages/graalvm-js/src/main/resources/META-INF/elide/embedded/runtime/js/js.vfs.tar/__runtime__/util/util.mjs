var p=Object.defineProperty;var t=(o,e)=>p(o,"name",{value:e,configurable:!0});function x(o,e){if(e){o.super_=e;var n=t(function(){},"TempCtor");n.prototype=e.prototype,o.prototype=new n,o.prototype.constructor=o}}t(x,"inherits");var c=globalThis.TextEncoder,i=globalThis.TextDecoder;export{i as TextDecoder,c as TextEncoder,x as inherits};
// Elide JS Builtins. Copyright (c) 2023-2024, Sam Gammon and Elide Technologies, Inc. All rights reserved.
// Components of this software are licensed separately. See https://github.com/elide-dev/elide for more.
