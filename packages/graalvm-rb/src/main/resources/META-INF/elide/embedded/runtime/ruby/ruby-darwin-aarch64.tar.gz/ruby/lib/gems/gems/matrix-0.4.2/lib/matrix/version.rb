# frozen_string_literal: true

class Matrix
  VERSION = "0.4.2"
end
