/**
 * Intrinsic: Buffer.
 *
 * Provides a shim which offers a `Buffer` implementation that is compatible with Node.js-style imports.
 */

module.exports = {Buffer: globalThis['Buffer']};
