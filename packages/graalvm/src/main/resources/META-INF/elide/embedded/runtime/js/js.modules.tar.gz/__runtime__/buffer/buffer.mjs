var e=globalThis.Buffer,f=e;export{e as Buffer};
// Elide JS Builtins. Copyright (c) 2023, Sam Gammon and the Elide Project Authors. All rights reserved.
// Components of this software are licensed separately. See https://github.com/elide-dev/elide for more.
