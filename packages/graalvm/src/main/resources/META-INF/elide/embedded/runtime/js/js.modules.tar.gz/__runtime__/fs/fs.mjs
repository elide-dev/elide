var s=Object.defineProperty;var r=(o,e)=>s(o,"name",{value:e,configurable:!0});var t={F_OK:0,R_OK:4,W_OK:2,X_OK:1};function c(o,e=t.F_OK,n){console.log("access fs",{path:o,mode:e,callback:n})}r(c,"access");var i={access:c};export{c as access};
// Elide JS Builtins. Copyright (c) 2023, Sam Gammon and the Elide Project Authors. All rights reserved.
// Components of this software are licensed separately. See https://github.com/elide-dev/elide for more.
