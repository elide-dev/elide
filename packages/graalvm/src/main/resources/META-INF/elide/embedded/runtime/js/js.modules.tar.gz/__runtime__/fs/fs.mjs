// elide/runtime/js/modules/fs/fs.ts
var fs_default = {
  hi: "hey"
};

// elide/runtime/js/modules/fs/index.ts
var fs_default2 = fs_default;
export {
  fs_default2 as default
};
