var i=Object.defineProperty;var n=(e,r)=>i(e,"name",{value:r,configurable:!0});var s=globalThis.__Elide_node_fs_promises__,t={F_OK:0,R_OK:4,W_OK:2,X_OK:1};function o(e,r=t.F_OK){return s.access(e,r)}n(o,"access");function _(e,r){return s.readFile(e,r)}n(_,"readFile");var c={access:o,constants:t,readFile:_};export{o as access,_ as readFile};
// Elide JS Builtins. Copyright (c) 2023, Sam Gammon and the Elide Project Authors. All rights reserved.
// Components of this software are licensed separately. See https://github.com/elide-dev/elide for more.
