var _=globalThis.__Elide_sqlite__,a=globalThis.__Elide_sqlite_Database__;export{a as Database};
// Elide JS Builtins. Copyright (c) 2023-2024, Sam Gammon and Elide Technologies, Inc. All rights reserved.
// Components of this software are licensed separately. See https://github.com/elide-dev/elide for more.
