// elide/runtime/js/modules/express/index.ts
function express() {
  return globalThis["express"]();
}
export default express;
