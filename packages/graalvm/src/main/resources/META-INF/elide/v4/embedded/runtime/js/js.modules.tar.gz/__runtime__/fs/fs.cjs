// elide/runtime/js/modules/fs/fs.ts
var fs_default = {
  hi: "hey"
};

// elide/runtime/js/modules/fs/index.ts
module.exports = fs_default;
